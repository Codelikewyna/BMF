# WonderCMS files for serving them through a CDN
- includes theme and plugins json list (which is cached by your WonderCMS)
- includes admin CSS and JS files

This repository serves the wcms-admin.js file, which provides a cached version of the themes/plugins list - faster experience for admins for logging in and checking for updates.
